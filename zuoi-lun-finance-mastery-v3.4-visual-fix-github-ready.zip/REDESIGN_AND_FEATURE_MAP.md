# Redesign and feature map

## Design direction

The v3.2 system combines Duna's core color language with an original hand-painted opening scene. Electric blue `#0000EE`, black `#000000`, brown-black `#292421` and warm off-white `#F7F7F5` still structure the learning UI; peach, blush, lavender and sand appear as gentle atmospheric layers in the hero. The result keeps the course structure, mascot and study-focused information hierarchy while making the first impression warmer and less corporate.

## Features learned from Accounting Mastery

| Accounting pattern | Finance v3.0 implementation |
| --- | --- |
| Shared mascot and application icon | zuòi lùn header mark, favicon, touch icon and installable icons |
| English theory with Vietnamese terminology support | Vietnamese translation appears beside each conceptual section, in the lesson key-term grid and in the bilingual glossary |
| Inline knowledge check after a lesson section | 144 open-response section self-checks plus 48 applied multiple-choice checks |
| Immediate answer feedback | Correct/wrong states, correct reasoning and explanation for every option |
| Active recall | Answer field, guided reveal, reasoning checklist and confidence marker |
| Local notes and progress | Existing Finance annotations, notes, lesson completion and progress are preserved |
| Global search | Search lessons, questions, formulas and key terms from any route |
| Clear source visibility | Priority-source banners and lesson source footers remain intact |

## Learning sequence inside a lesson

1. Anchor the key principle.
2. Read the deep explanation.
3. Study each conceptual section with nearby English–Vietnamese terms.
4. Answer that section's self-check before revealing the model answer.
5. Complete the one-minute applied knowledge check.
6. Place events or cash flows on the timeline.
7. Read formulas by variables, use conditions and traps.
8. Follow worked applications.
9. Solve Easy → Intermediate → Advanced guided problems.
10. Review exam traps and complete lesson-specific practice.

## Content-preservation rule

The redesign changes presentation and adds learning scaffolding. It does not remove the original key principles, source-aligned theory, 600-question bank, formulas, timelines, guided problems, calculators or learner utilities.
